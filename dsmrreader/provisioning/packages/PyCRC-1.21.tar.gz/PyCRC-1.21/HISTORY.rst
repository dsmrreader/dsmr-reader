.. :changelog:

History
-------

1.2 (2015-03-10)
---------------------
* Cosmetic Refactoring

1.1 (2014-05-01)
---------------------

* Migration to python 3

1.0 (2011-10-10)
---------------------

* Initial launch

